from module.map.map_base import CampaignMap
from module.map.map_grids import SelectedGrids, RoadGrids
from module.logger import logger

from .campaign_16_base_submarine import CampaignBase
from .campaign_16_base_submarine import Config as ConfigBase

MAP = CampaignMap('16-1')
MAP.shape = 'I9'
MAP.camera_data = ['C2', 'C6', 'F2', 'F5']
MAP.camera_data_spawn_point = ['F7']
MAP.camera_sight = (-2, -1, 3, 2)
MAP.map_data = """
    ++ ME -- -- ME -- -- ME --
    ME -- -- ME ++ ME -- -- ME
    -- -- ME -- ME -- -- ME ++
    -- ME ++ ME -- ME -- ME Me
    -- -- ME -- Me ++ __ -- --
    -- ME -- __ ME -- -- -- MB
    -- ++ Me -- -- -- Me ++ ++
    -- ME -- -- -- -- -- ++ ++
    -- -- -- -- SP SP ++ ++ --
"""
MAP.weight_data = """
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
    50 50 50 50 50 50 50 50 50
"""
MAP.spawn_data = [
    {'battle': 0, 'enemy': 2},
    {'battle': 1, 'enemy': 2},
    {'battle': 2, 'enemy': 2},
    {'battle': 3, 'enemy': 1},
    {'battle': 4, 'enemy': 1},
    {'battle': 5, 'boss': 1}
]
A1, B1, C1, D1, E1, F1, G1, H1, I1, \
A2, B2, C2, D2, E2, F2, G2, H2, I2, \
A3, B3, C3, D3, E3, F3, G3, H3, I3, \
A4, B4, C4, D4, E4, F4, G4, H4, I4, \
A5, B5, C5, D5, E5, F5, G5, H5, I5, \
A6, B6, C6, D6, E6, F6, G6, H6, I6, \
A7, B7, C7, D7, E7, F7, G7, H7, I7, \
A8, B8, C8, D8, E8, F8, G8, H8, I8, \
A9, B9, C9, D9, E9, F9, G9, H9, I9, \
    = MAP.flatten()


class Config(ConfigBase):
    MAP_HAS_MAP_STORY = False
    MAP_HAS_FLEET_STEP = False
    MAP_HAS_AMBUSH = True

    MAP_ENSURE_EDGE_INSIGHT_CORNER = 'bottom-right'
    MAP_SWIPE_MULTIPLY = (1.050, 1.069)
    MAP_SWIPE_MULTIPLY_MINITOUCH = (1.015, 1.034)
    MAP_SWIPE_MULTIPLY_MAATOUCH = (0.985, 1.003)


class Campaign(CampaignBase):
    MAP = MAP

    def battle_0(self):
        if self.clear_filter_enemy(self.ENEMY_FILTER, preserve=1):
            return True

        return self.battle_default()

    def battle_5(self):
        boss = self.map.select(is_boss=True)
        if boss:
            return self.fleet_boss.clear_boss()

        if self.clear_filter_enemy(self.ENEMY_FILTER, preserve=0):
            return True

        return self.battle_default()

    def battle_6(self):
        return self.fleet_boss.clear_boss()
